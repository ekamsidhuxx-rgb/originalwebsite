const mongoose = require('mongoose')

const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  price: { type: Number, required: true },
  description: { type: String, default: '' },
  image: { type: String, default: '' },
  category: { type: String, default: 'All' },
  stock: { type: Number, default: 10 },
  featured: { type: Boolean, default: false },
  discount: { type: Number, default: 0 },
  badge: { type: String, default: '' },
}, { timestamps: true })

module.exports = mongoose.model('Product', productSchema)
