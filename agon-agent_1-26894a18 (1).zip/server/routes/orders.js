const express = require('express')
const router = express.Router()
const Order = require('../models/Order')
const { verifyToken } = require('../middleware/auth')

// Create order
router.post('/', async (req, res) => {
  try {
    const { customerName, phone, address, items, total } = req.body

    const message = `Hello SIDHU team,%0A%0AI want to place an order:%0A%0A*Customer:* ${encodeURIComponent(customerName)}%0A*Phone:* ${phone}%0A*Address:* ${encodeURIComponent(address)}%0A%0A*Items:*%0A${items.map(i => `- ${i.name} x${i.quantity} = ₹${i.price * i.quantity}`).join('%0A')}%0A%0A*Total:* ₹${total}%0A%0APlease confirm.`
    const whatsappLink = `https://wa.me/919988563942?text=${message}`

    const order = new Order({ customerName, phone, address, items, total, whatsappLink })
    const saved = await order.save()
    res.status(201).json({ order: saved, whatsappLink })
  } catch (err) {
    res.status(400).json({ message: err.message })
  }
})

// Get all orders (protected)
router.get('/', verifyToken, async (req, res) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 })
    res.json(orders)
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

// Update order status (protected)
router.put('/:id', verifyToken, async (req, res) => {
  try {
    const updated = await Order.findByIdAndUpdate(req.params.id, req.body, { new: true })
    if (!updated) return res.status(404).json({ message: 'Order not found' })
    res.json(updated)
  } catch (err) {
    res.status(400).json({ message: err.message })
  }
})

module.exports = router
