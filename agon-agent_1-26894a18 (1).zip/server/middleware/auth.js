const jwt = require('jsonwebtoken')

const JWT_SECRET = process.env.JWT_SECRET || 'sidhu_secret_key'

function verifyToken(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1]
  if (!token) return res.status(401).json({ message: 'Unauthorized' })

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) return res.status(403).json({ message: 'Invalid token' })
    req.admin = decoded
    next()
  })
}

module.exports = { verifyToken, JWT_SECRET }
