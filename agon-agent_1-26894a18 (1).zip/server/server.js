require('dotenv').config()
const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')
const path = require('path')

const productRoutes = require('./routes/products')
const orderRoutes = require('./routes/orders')
const authRoutes = require('./routes/auth')

const app = express()
const PORT = process.env.PORT || 5000
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/sidhu'

app.use(cors())
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true, limit: '10mb' }))

// API routes
app.use('/api/products', productRoutes)
app.use('/api/orders', orderRoutes)
app.use('/api/auth', authRoutes)

// Serve static files
app.use(express.static(path.join(__dirname, '../dist')))
app.use('/admin', express.static(path.join(__dirname, '../admin')))

// Fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../dist/index.html'))
})

async function startServer() {
  try {
    await mongoose.connect(MONGO_URI)
    console.log('MongoDB connected')
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`))
  } catch (err) {
    console.error('MongoDB connection error:', err)
    // Still start server even if DB fails, for static site
    app.listen(PORT, () => console.log(`Server running on port ${PORT} (without DB)`))
  }
}

startServer()

module.exports = app
