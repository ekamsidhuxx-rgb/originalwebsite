require('dotenv').config()
const mongoose = require('mongoose')
const Product = require('./models/Product')
const Admin = require('./models/Admin')

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/sidhu'

const initialProducts = [
  { name: 'Oversized Black T-Shirt', price: 499, category: 'T-Shirts', stock: 50, badge: 'Best Seller', featured: true, description: 'Premium heavyweight oversized tee crafted for everyday streetwear.', image: '' },
  { name: 'Premium White Hoodie', price: 999, category: 'Hoodies', stock: 35, badge: 'New', featured: true, description: 'Ultra-soft fleece hoodie with minimal SIDHU branding.', image: '' },
  { name: 'Denim Jacket Classic', price: 1499, category: 'Jackets', stock: 20, badge: '', featured: true, description: 'Timeless denim jacket with a vintage washed finish.', image: '' },
  { name: 'Cargo Pants Streetwear', price: 1299, category: 'Bottoms', stock: 25, badge: 'Trending', featured: false, description: 'Utility cargo pants with multiple pockets and relaxed fit.', image: '' },
  { name: 'Minimal Grey Sweatshirt', price: 899, category: 'Sweatshirts', stock: 40, badge: '', featured: false, description: 'Clean minimal sweatshirt perfect for layering.', image: '' },
  { name: 'Urban Sneakers', price: 1999, category: 'Footwear', stock: 15, badge: 'Limited', featured: true, description: 'Statement urban sneakers built for all-day comfort.', image: '' },
  { name: 'Street Cap', price: 399, category: 'Accessories', stock: 60, badge: '', featured: false, description: 'Classic 6-panel cap with embroidered SIDHU logo.', image: '' },
  { name: 'Winter Jacket Pro', price: 2499, category: 'Jackets', stock: 12, badge: 'Premium', featured: true, description: 'Heavy-duty winter jacket with insulated lining.', image: '' },
]

async function seed() {
  try {
    await mongoose.connect(MONGO_URI)
    console.log('Connected to MongoDB')

    await Product.deleteMany()
    await Product.insertMany(initialProducts)
    console.log('Products seeded')

    await Admin.deleteMany()
    await Admin.create({ username: 'admin', password: 'admin123' })
    console.log('Admin created: admin / admin123')

    process.exit()
  } catch (err) {
    console.error(err)
    process.exit(1)
  }
}

seed()
