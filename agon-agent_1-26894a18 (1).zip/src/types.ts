export interface Product {
  _id: string
  name: string
  price: number
  description: string
  image: string
  category: string
  stock: number
  featured: boolean
  badge: string
}

export interface CartItem extends Product {
  quantity: number
}

export interface OrderItem {
  productId: string
  name: string
  price: number
  quantity: number
}

export interface Address {
  house?: string
  street: string
  area: string
  landmark?: string
  city: string
  state: string
  pincode: string
}

export interface Order {
  id: string
  name: string
  phone: string
  address: Address
  paymentMethod: string
  paymentStatus: string
  status: string
  items: OrderItem[]
  total: number
  createdAt: string
}
