import { X, Plus, Minus, ShoppingBag } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { Link } from 'react-router-dom'
import type { CartItem } from '../types'
import { ProductImage } from './ProductCard'

interface Props {
  isOpen: boolean
  onClose: () => void
  cart: CartItem[]
  total: number
  onUpdateQuantity: (id: string, delta: number) => void
  onRemove: (id: string) => void
}

export function CartDrawer({ isOpen, onClose, cart, total, onUpdateQuantity, onRemove }: Props) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] bg-black/60 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 bottom-0 z-[80] w-full max-w-md bg-[#0f0f0f] border-l border-white/10 flex flex-col"
          >
            <div className="flex items-center justify-between p-6 border-b border-white/10">
              <h3 className="text-xl font-bold">Your Cart ({cart.reduce((a, b) => a + b.quantity, 0)})</h3>
              <button onClick={onClose} aria-label="Close cart">
                <X size={24} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {cart.length === 0 ? (
                <div className="text-center text-white/50 mt-12">
                  <ShoppingBag size={48} className="mx-auto mb-4 opacity-30" />
                  <p>Your cart is empty</p>
                </div>
              ) : (
                cart.map((item) => (
                  <div key={item._id} className="flex gap-4">
                    <div className="w-20 h-24 bg-white/5 flex-shrink-0 flex items-center justify-center rounded overflow-hidden">
                      <ProductImage product={item} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-sm mb-1">{item.name}</h4>
                      <p className="text-white/50 text-sm mb-2">₹{item.price}</p>
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => onUpdateQuantity(item._id, -1)}
                          className="w-7 h-7 border border-white/10 flex items-center justify-center hover:bg-white/5"
                        >
                          <Minus size={12} />
                        </button>
                        <span className="text-sm w-4 text-center">{item.quantity}</span>
                        <button
                          onClick={() => onUpdateQuantity(item._id, 1)}
                          className="w-7 h-7 border border-white/10 flex items-center justify-center hover:bg-white/5"
                        >
                          <Plus size={12} />
                        </button>
                      </div>
                    </div>
                    <button onClick={() => onRemove(item._id)} className="text-white/30 hover:text-white self-start">
                      <X size={18} />
                    </button>
                  </div>
                ))
              )}
            </div>

            {cart.length > 0 && (
              <div className="p-6 border-t border-white/10 space-y-4">
                <div className="flex justify-between text-xl font-bold">
                  <span>Total</span>
                  <span>₹{total.toFixed(0)}</span>
                </div>
                <Link
                  to="/checkout"
                  onClick={onClose}
                  className="block w-full bg-white text-black text-center py-4 font-semibold hover:bg-white/90 transition-colors"
                >
                  Checkout
                </Link>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
