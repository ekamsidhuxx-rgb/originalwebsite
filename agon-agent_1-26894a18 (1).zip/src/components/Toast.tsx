import { AnimatePresence, motion } from 'framer-motion'

interface Props {
  message: string | null
}

export function Toast({ message }: Props) {
  return (
    <AnimatePresence>
      {message && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] bg-white text-black px-6 py-3 rounded-full font-medium shadow-2xl"
        >
          {message}
        </motion.div>
      )}
    </AnimatePresence>
  )
}
