import { motion } from 'framer-motion'
import type { Product } from '../types'

interface Props {
  product: Product
  onClick: () => void
  onAdd: (product: Product) => void
}

export function ProductCard({ product, onClick, onAdd }: Props) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="group relative"
    >
      <div
        className="relative aspect-[3/4] bg-white/5 overflow-hidden rounded-lg mb-4 cursor-pointer"
        onClick={onClick}
      >
        <ProductImage product={product} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
        {product.badge && (
          <span className="absolute top-3 left-3 bg-white text-black text-[10px] font-bold px-3 py-1 uppercase tracking-wide">
            {product.badge}
          </span>
        )}
        <button
          onClick={(e) => {
            e.stopPropagation()
            onAdd(product)
          }}
          className="absolute bottom-0 left-0 right-0 bg-white text-black py-3 font-semibold translate-y-full group-hover:translate-y-0 transition-transform duration-300"
        >
          Add to Cart
        </button>
      </div>
      <div onClick={onClick} className="cursor-pointer">
        <p className="text-white/50 text-xs uppercase tracking-wider mb-1">{product.category}</p>
        <h4 className="font-medium mb-1 truncate">{product.name}</h4>
        <p className="font-semibold">₹{product.price}</p>
      </div>
    </motion.div>
  )
}

export function ProductImage({ product, className }: { product: Product; className?: string }) {
  if (product.image) {
    return <img src={product.image} alt={product.name} className={className} loading="lazy" />
  }
  return (
    <div className={`bg-gradient-to-br from-white/10 to-white/5 flex items-center justify-center ${className}`}>
      <span className="text-white/20 font-bold text-4xl">{product.name.charAt(0)}</span>
    </div>
  )
}
