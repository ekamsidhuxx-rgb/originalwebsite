import { useState } from 'react'
import { Search, ShoppingBag, Menu, X, User } from 'lucide-react'
import { Link } from 'react-router-dom'

interface Props {
  cartCount: number
  search: string
  setSearch: (value: string) => void
  onOpenCart: () => void
}

export function Navbar({ cartCount, search, setSearch, onOpenCart }: Props) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0a0a0a]/90 backdrop-blur-xl border-b border-white/10 py-4">
        <div className="w-full px-6 lg:px-12 flex items-center justify-between">
          <button className="md:hidden text-white" onClick={() => setMobileMenuOpen(true)} aria-label="Menu">
            <Menu size={24} />
          </button>

          <ul className="hidden md:flex items-center gap-8">
            <li><Link to="/" className="text-sm font-medium tracking-wide text-white/80 hover:text-white transition-colors">Shop</Link></li>
            <li><Link to="/#featured" className="text-sm font-medium tracking-wide text-white/80 hover:text-white transition-colors">Featured</Link></li>
            <li><Link to="/admin" className="text-sm font-medium tracking-wide text-white/80 hover:text-white transition-colors">Admin</Link></li>
          </ul>

          <Link to="/" className="absolute left-1/2 -translate-x-1/2">
            <h1 className="text-2xl md:text-3xl font-bold tracking-[0.2em] uppercase">SIDHU</h1>
          </Link>

          <div className="flex items-center gap-5">
            <div className="hidden md:flex items-center bg-white/5 border border-white/10 rounded-full px-4 py-2">
              <Search size={16} className="text-white/50" />
              <input
                type="text"
                placeholder="Search..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="bg-transparent border-none outline-none text-sm ml-2 w-32 text-white placeholder:text-white/40"
              />
            </div>
            <Link to="/admin" aria-label="Account" className="hover:opacity-70 transition-opacity hidden md:block">
              <User size={20} />
            </Link>
            <button
              className="relative hover:opacity-70 transition-opacity"
              onClick={onOpenCart}
              aria-label="Cart"
            >
              <ShoppingBag size={20} />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-white text-black text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </nav>

      {mobileMenuOpen && (
        <div className="fixed inset-0 z-[60] bg-[#0a0a0a] flex flex-col p-6">
          <div className="flex justify-end">
            <button onClick={() => setMobileMenuOpen(false)} aria-label="Close">
              <X size={28} />
            </button>
          </div>
          <ul className="flex flex-col gap-8 mt-12">
            {['Shop', 'Featured', 'Admin'].map((link) => (
              <li key={link}>
                <Link
                  to={link === 'Shop' ? '/' : link === 'Admin' ? '/admin' : '/#featured'}
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-3xl font-light tracking-widest"
                >
                  {link}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}
    </>
  )
}
