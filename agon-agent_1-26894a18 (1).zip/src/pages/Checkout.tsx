import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import type { CartItem, Order, Address } from '../types'

interface Props {
  cart: CartItem[]
  total: number
  onPlaceOrder: (
    name: string,
    phone: string,
    address: Address,
    paymentMethod: string,
    items: CartItem[]
  ) => Order
  onClearCart: () => void
}

export function Checkout({ cart, total, onPlaceOrder, onClearCart }: Props) {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState('cod')

  const [customer, setCustomer] = useState({ name: '', phone: '' })
  const [address, setAddress] = useState<Address>({
    house: '',
    street: '',
    area: '',
    landmark: '',
    city: '',
    state: '',
    pincode: '',
  })

  if (cart.length === 0) {
    return (
      <div className="min-h-screen pt-32 px-6 text-center">
        <h2 className="text-3xl font-bold mb-4">Your cart is empty</h2>
        <p className="text-white/60 mb-8">Add some products before checkout.</p>
        <button
          onClick={() => navigate('/')}
          className="bg-white text-black px-8 py-3 font-semibold hover:bg-white/90 transition-colors"
        >
          Continue Shopping
        </button>
      </div>
    )
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!customer.name || !customer.phone) return
    if (!address.street || !address.area || !address.city || !address.state || !address.pincode) return

    setLoading(true)

    const finalAddress: Address = {
      house: address.house || undefined,
      street: address.street,
      area: address.area,
      landmark: address.landmark || undefined,
      city: address.city,
      state: address.state,
      pincode: address.pincode,
    }

    onPlaceOrder(customer.name, customer.phone, finalAddress, paymentMethod, cart)
    onClearCart()
    navigate('/')
  }

  const inputClass =
    'w-full bg-white/5 border border-white/10 px-4 py-3 outline-none focus:border-white/30 transition-colors text-sm'

  return (
    <div className="min-h-screen pt-28 pb-16 px-6 lg:px-12">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold mb-2">Checkout</h2>
        <p className="text-white/50 mb-8">Complete your order details below</p>

        <form onSubmit={handleSubmit} className="grid lg:grid-cols-5 gap-10">
          {/* Left: Forms */}
          <div className="lg:col-span-3 space-y-8">
            {/* Customer Details */}
            <section className="bg-white/[0.03] border border-white/10 rounded-xl p-6">
              <h3 className="text-lg font-semibold mb-5">Customer Details</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-white/60 mb-1.5">Full Name *</label>
                  <input
                    type="text"
                    value={customer.name}
                    onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
                    className={inputClass}
                    placeholder="John Doe"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs text-white/60 mb-1.5">Mobile Number *</label>
                  <input
                    type="tel"
                    value={customer.phone}
                    onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
                    className={inputClass}
                    placeholder="9876543210"
                    required
                  />
                </div>
              </div>
            </section>

            {/* Address */}
            <section className="bg-white/[0.03] border border-white/10 rounded-xl p-6">
              <h3 className="text-lg font-semibold mb-5">Delivery Address</h3>

              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-xs text-white/60 mb-1.5">
                    House / Flat / Building No <span className="text-white/30">(optional)</span>
                  </label>
                  <input
                    type="text"
                    value={address.house}
                    onChange={(e) => setAddress({ ...address, house: e.target.value })}
                    className={inputClass}
                    placeholder="12B"
                  />
                </div>
                <div>
                  <label className="block text-xs text-white/60 mb-1.5">
                    Landmark <span className="text-white/30">(optional)</span>
                  </label>
                  <input
                    type="text"
                    value={address.landmark}
                    onChange={(e) => setAddress({ ...address, landmark: e.target.value })}
                    className={inputClass}
                    placeholder="Near City Mall"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-xs text-white/60 mb-1.5">Street / Road Name *</label>
                  <input
                    type="text"
                    value={address.street}
                    onChange={(e) => setAddress({ ...address, street: e.target.value })}
                    className={inputClass}
                    placeholder="Main Street"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs text-white/60 mb-1.5">Area / Colony / Locality *</label>
                  <input
                    type="text"
                    value={address.area}
                    onChange={(e) => setAddress({ ...address, area: e.target.value })}
                    className={inputClass}
                    placeholder="Green Valley"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs text-white/60 mb-1.5">City *</label>
                  <input
                    type="text"
                    value={address.city}
                    onChange={(e) => setAddress({ ...address, city: e.target.value })}
                    className={inputClass}
                    placeholder="Mumbai"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs text-white/60 mb-1.5">State *</label>
                  <input
                    type="text"
                    value={address.state}
                    onChange={(e) => setAddress({ ...address, state: e.target.value })}
                    className={inputClass}
                    placeholder="Maharashtra"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs text-white/60 mb-1.5">Pincode *</label>
                  <input
                    type="text"
                    value={address.pincode}
                    onChange={(e) => setAddress({ ...address, pincode: e.target.value })}
                    className={inputClass}
                    placeholder="400001"
                    required
                  />
                </div>
              </div>
            </section>

            {/* Payment */}
            <section className="bg-white/[0.03] border border-white/10 rounded-xl p-6">
              <h3 className="text-lg font-semibold mb-5">Payment Method</h3>

              <label className="flex items-center gap-3 p-4 border border-white/10 rounded-lg cursor-pointer hover:bg-white/5 transition-colors mb-3">
                <input
                  type="radio"
                  name="payment"
                  value="cod"
                  checked={paymentMethod === 'cod'}
                  onChange={() => setPaymentMethod('cod')}
                  className="w-4 h-4 accent-white"
                />
                <div>
                  <p className="font-medium">Cash on Delivery</p>
                  <p className="text-xs text-white/50">Pay when you receive your order</p>
                </div>
              </label>

              <label className="flex items-center gap-3 p-4 border border-white/10 rounded-lg cursor-not-allowed opacity-50">
                <input
                  type="radio"
                  name="payment"
                  value="online"
                  checked={paymentMethod === 'online'}
                  onChange={() => setPaymentMethod('online')}
                  disabled
                  className="w-4 h-4 accent-white"
                />
                <div>
                  <p className="font-medium">Online Payment</p>
                  <p className="text-xs text-white/50">Coming soon</p>
                </div>
              </label>
            </section>
          </div>

          {/* Right: Order Summary */}
          <div className="lg:col-span-2">
            <div className="bg-white/[0.03] border border-white/10 rounded-xl p-6 sticky top-28">
              <h3 className="text-lg font-semibold mb-5">Order Summary</h3>

              <div className="space-y-3 max-h-64 overflow-y-auto pr-2">
                {cart.map((item) => (
                  <div key={item._id} className="flex justify-between text-sm">
                    <div>
                      <p className="text-white/90">{item.name}</p>
                      <p className="text-white/40 text-xs">Qty: {item.quantity}</p>
                    </div>
                    <span className="font-medium">₹{(item.price * item.quantity).toFixed(0)}</span>
                  </div>
                ))}
              </div>

              <div className="border-t border-white/10 mt-5 pt-5 space-y-2">
                <div className="flex justify-between text-sm text-white/60">
                  <span>Subtotal</span>
                  <span>₹{total.toFixed(0)}</span>
                </div>
                <div className="flex justify-between text-sm text-white/60">
                  <span>Shipping</span>
                  <span>Free</span>
                </div>
              </div>

              <div className="border-t border-white/10 mt-4 pt-4 flex justify-between text-xl font-bold">
                <span>Total</span>
                <span>₹{total.toFixed(0)}</span>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-white text-black py-4 font-semibold hover:bg-white/90 transition-colors disabled:opacity-50 mt-6"
              >
                {loading ? 'Placing Order...' : 'Place Order'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}
