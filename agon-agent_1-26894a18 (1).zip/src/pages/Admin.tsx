import { useState } from 'react'
import type { Order, Address } from '../types'

interface Props {
  orders: Order[]
  onDeleteOrder: (id: string) => void
}

function formatAddress(address: Address) {
  const house = address.house?.trim() || 'N/A'
  const landmark = address.landmark?.trim() || 'N/A'

  return (
    <div className="text-sm space-y-1">
      <p><span className="text-white/50">House/Flat:</span> {house}</p>
      <p><span className="text-white/50">Street:</span> {address.street}</p>
      <p><span className="text-white/50">Area:</span> {address.area}</p>
      <p><span className="text-white/50">Landmark:</span> {landmark}</p>
      <p><span className="text-white/50">City:</span> {address.city}</p>
      <p><span className="text-white/50">State:</span> {address.state}</p>
      <p><span className="text-white/50">Pincode:</span> {address.pincode}</p>
    </div>
  )
}

export function Admin({ orders, onDeleteOrder }: Props) {
  const [loggedIn, setLoggedIn] = useState(false)
  const [form, setForm] = useState({ user: '', pass: '' })

  if (!loggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="w-full max-w-md bg-[#111] border border-white/10 rounded-xl p-8">
          <h2 className="text-2xl font-bold text-center mb-8 tracking-wide">SIDHU Admin</h2>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              if (form.user === 'admin' && form.pass === '1234') {
                setLoggedIn(true)
              } else {
                alert('Wrong credentials')
              }
            }}
            className="space-y-4"
          >
            <input
              type="text"
              placeholder="Username"
              value={form.user}
              onChange={(e) => setForm({ ...form, user: e.target.value })}
              className="w-full bg-white/5 border border-white/10 px-4 py-3 outline-none focus:border-white/30"
            />
            <input
              type="password"
              placeholder="Password"
              value={form.pass}
              onChange={(e) => setForm({ ...form, pass: e.target.value })}
              className="w-full bg-white/5 border border-white/10 px-4 py-3 outline-none focus:border-white/30"
            />
            <button type="submit" className="w-full bg-white text-black py-3 font-semibold hover:bg-white/90 transition-colors">
              Login
            </button>
          </form>
          <p className="text-white/30 text-xs text-center mt-6">Default: admin / 1234</p>
        </div>
      </div>
    )
  }

  const totalSales = orders.reduce((sum, order) => sum + order.total, 0)

  return (
    <div className="min-h-screen pt-24 pb-16 px-6 lg:px-12">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold">Admin Dashboard</h2>
            <p className="text-white/50">Manage orders and view sales</p>
          </div>
          <button
            onClick={() => setLoggedIn(false)}
            className="px-5 py-2 border border-white/20 hover:bg-white/5 transition-colors text-sm"
          >
            Logout
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          <div className="bg-white/5 border border-white/10 p-6 rounded-lg">
            <p className="text-white/50 text-sm mb-1">Total Orders</p>
            <p className="text-3xl font-bold">{orders.length}</p>
          </div>
          <div className="bg-white/5 border border-white/10 p-6 rounded-lg">
            <p className="text-white/50 text-sm mb-1">Total Sales</p>
            <p className="text-3xl font-bold">₹{totalSales.toFixed(0)}</p>
          </div>
          <div className="bg-white/5 border border-white/10 p-6 rounded-lg">
            <p className="text-white/50 text-sm mb-1">Products</p>
            <p className="text-3xl font-bold">8</p>
          </div>
        </div>

        <h3 className="text-xl font-semibold mb-4">Orders</h3>

        {orders.length === 0 ? (
          <div className="text-center text-white/40 py-16 bg-white/5 border border-white/10 rounded-lg">
            <p>No orders yet.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => (
              <div key={order.id} className="bg-white/5 border border-white/10 p-6 rounded-lg">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                  <div>
                    <p className="text-white/50 text-sm">Order #{order.id}</p>
                    <p className="text-lg font-semibold">{order.name}</p>
                  </div>
                  <div className="text-left md:text-right">
                    <p className="text-2xl font-bold">₹{order.total.toFixed(0)}</p>
                    <p className="text-white/50 text-sm">{new Date(order.createdAt).toLocaleString()}</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6 mb-4">
                  <div>
                    <p className="text-white/50 text-sm mb-1">Phone</p>
                    <p className="text-sm">{order.phone}</p>
                  </div>
                  <div>
                    <p className="text-white/50 text-sm mb-1">Payment</p>
                    <p className="text-sm capitalize">{order.paymentMethod === 'cod' ? 'Cash on Delivery' : order.paymentMethod}</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6 mb-4">
                  <div>
                    <p className="text-white/50 text-sm mb-2">Address</p>
                    {formatAddress(order.address)}
                  </div>
                  <div>
                    <p className="text-white/50 text-sm mb-2">Items</p>
                    <ul className="space-y-1 text-sm">
                      {order.items.map((item, idx) => (
                        <li key={idx} className="flex justify-between max-w-sm">
                          <span>{item.name} x{item.quantity}</span>
                          <span>₹{(item.price * item.quantity).toFixed(0)}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="flex flex-wrap gap-3 mb-4">
                  <span className="text-xs px-3 py-1 rounded-full bg-yellow-500/20 text-yellow-400">
                    Status: {order.status}
                  </span>
                  <span className="text-xs px-3 py-1 rounded-full bg-red-500/20 text-red-400">
                    Payment: {order.paymentStatus}
                  </span>
                </div>

                <button
                  onClick={() => onDeleteOrder(order.id)}
                  className="bg-red-600 text-white px-4 py-2 rounded text-sm hover:bg-red-700 transition-colors"
                >
                  Delete Order
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
