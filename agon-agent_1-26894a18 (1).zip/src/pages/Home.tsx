import { useState, useMemo } from 'react'
import { ArrowRight, Star, Shield, Truck, RotateCcw } from 'lucide-react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { products } from '../data/products'
import { ProductCard, ProductImage } from '../components/ProductCard'
import type { Product } from '../types'

const categories = ['All', 'T-Shirts', 'Hoodies', 'Jackets', 'Bottoms', 'Sweatshirts', 'Footwear', 'Accessories']

interface Props {
  onAddToCart: (product: Product) => void
  search: string
}

export function Home({ onAddToCart, search }: Props) {
  const [category, setCategory] = useState('All')
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase())
      const matchesCategory = category === 'All' || p.category === category
      return matchesSearch && matchesCategory
    })
  }, [search, category])

  const featuredProducts = useMemo(() => products.filter((p) => p.featured), [])

  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#111] via-[#0a0a0a] to-[#1a1a1a]" />
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-white/5 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 text-center px-6 max-w-5xl">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-white/50 tracking-[0.3em] uppercase text-sm mb-6"
          >
            Premium Streetwear
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight mb-8"
          >
            DEFINE YOUR <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-white/40">STREET</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-white/60 text-lg md:text-xl max-w-2xl mx-auto mb-10"
          >
            Luxury fashion essentials crafted for the bold. Premium quality, timeless design, unmatched comfort.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <a href="#shop" className="px-8 py-4 bg-white text-black font-semibold tracking-wide hover:bg-white/90 transition-colors">
              Shop Now
            </a>
            <a href="#featured" className="px-8 py-4 border border-white/20 hover:bg-white/5 transition-colors tracking-wide">
              View Collection
            </a>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-6 lg:px-12 border-y border-white/10">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
          {[
            { icon: Truck, title: 'Free Shipping', desc: 'On orders above ₹999' },
            { icon: Shield, title: 'Premium Quality', desc: 'Handpicked materials' },
            { icon: RotateCcw, title: 'Easy Returns', desc: '7-day return policy' },
            { icon: Star, title: 'Top Rated', desc: 'Loved by 10,000+ customers' },
          ].map((feature, i) => (
            <div key={i} className="flex items-center gap-4 p-4">
              <feature.icon size={28} className="text-white/70" />
              <div>
                <h4 className="font-semibold">{feature.title}</h4>
                <p className="text-white/50 text-sm">{feature.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Featured */}
      <section id="featured" className="py-24 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="text-white/50 tracking-widest uppercase text-sm mb-2">Curated For You</p>
              <h3 className="text-3xl md:text-4xl font-bold">Featured Collection</h3>
            </div>
            <a href="#shop" className="hidden md:flex items-center gap-2 text-sm hover:opacity-70 transition-opacity">
              View All <ArrowRight size={16} />
            </a>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {featuredProducts.slice(0, 4).map((product) => (
              <ProductCard key={product._id} product={product} onClick={() => setSelectedProduct(product)} onAdd={onAddToCart} />
            ))}
          </div>
        </div>
      </section>

      {/* Shop */}
      <section id="shop" className="py-24 px-6 lg:px-12 bg-[#0f0f0f]">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div>
              <p className="text-white/50 tracking-widest uppercase text-sm mb-2">Explore</p>
              <h3 className="text-3xl md:text-4xl font-bold">All Products</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`px-4 py-2 text-sm border transition-all ${
                    category === cat
                      ? 'bg-white text-black border-white'
                      : 'border-white/10 text-white/70 hover:border-white/30'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard key={product._id} product={product} onClick={() => setSelectedProduct(product)} onAdd={onAddToCart} />
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-24 px-6 lg:px-12 border-t border-white/10">
        <div className="max-w-3xl mx-auto text-center">
          <h3 className="text-3xl md:text-4xl font-bold mb-4">Join the SIDHU Circle</h3>
          <p className="text-white/60 mb-8">Get exclusive drops, early access, and member-only discounts.</p>
          <form className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto" onSubmit={(e) => e.preventDefault()}>
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 bg-white/5 border border-white/10 px-5 py-3 outline-none focus:border-white/30 transition-colors"
            />
            <button type="submit" className="bg-white text-black px-8 py-3 font-semibold hover:bg-white/90 transition-colors">
              Subscribe
            </button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#050505] py-16 px-6 lg:px-12 border-t border-white/10">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div>
            <h4 className="text-2xl font-bold tracking-[0.2em] mb-4">SIDHU</h4>
            <p className="text-white/50 text-sm">Premium streetwear for the new generation. Built with passion, designed for impact.</p>
          </div>
          <div>
            <h5 className="font-semibold mb-4">Shop</h5>
            <ul className="space-y-2 text-white/50 text-sm">
              <li><Link to="/" className="hover:text-white transition-colors">All Products</Link></li>
              <li><Link to="/#featured" className="hover:text-white transition-colors">Featured</Link></li>
              <li><Link to="/" className="hover:text-white transition-colors">New Arrivals</Link></li>
              <li><Link to="/" className="hover:text-white transition-colors">Sale</Link></li>
            </ul>
          </div>
          <div>
            <h5 className="font-semibold mb-4">Support</h5>
            <ul className="space-y-2 text-white/50 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Shipping Info</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Returns</a></li>
              <li><Link to="/admin" className="hover:text-white transition-colors">Admin Login</Link></li>
            </ul>
          </div>
          <div>
            <h5 className="font-semibold mb-4">Contact</h5>
            <ul className="space-y-2 text-white/50 text-sm">
              <li>support@sidhu.com</li>
              <li>+91 99885 63942</li>
              <li>Mumbai, India</li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-white/10 text-center text-white/40 text-sm">
          © 2025 SIDHU. All rights reserved.
        </div>
      </footer>

      {/* Product Modal */}
      {selectedProduct && (
        <div
          className="fixed inset-0 z-[70] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setSelectedProduct(null)}
        >
          <div
            className="bg-[#111] border border-white/10 max-w-4xl w-full max-h-[90vh] overflow-y-auto rounded-lg grid md:grid-cols-2 animate-fade-in"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="aspect-square bg-white/5 flex items-center justify-center p-8">
              <ProductImage product={selectedProduct} className="max-h-full max-w-full object-contain" />
            </div>
            <div className="p-8 flex flex-col">
              <button onClick={() => setSelectedProduct(null)} className="self-end text-white/50 hover:text-white mb-4">
                X
              </button>
              <p className="text-white/50 text-sm tracking-widest uppercase mb-2">{selectedProduct.category}</p>
              <h3 className="text-3xl font-bold mb-2">{selectedProduct.name}</h3>
              <p className="text-2xl font-semibold mb-6">₹{selectedProduct.price}</p>
              <p className="text-white/60 mb-8 leading-relaxed">{selectedProduct.description}</p>
              <button
                onClick={() => {
                  onAddToCart(selectedProduct)
                  setSelectedProduct(null)
                }}
                className="mt-auto bg-white text-black py-4 font-semibold hover:bg-white/90 transition-colors"
              >
                Add to Cart
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
