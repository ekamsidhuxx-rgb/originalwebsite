import { useState } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Navbar } from './components/Navbar'
import { CartDrawer } from './components/CartDrawer'
import { Toast } from './components/Toast'
import { Home } from './pages/Home'
import { Checkout } from './pages/Checkout'
import { Admin } from './pages/Admin'
import { useCart } from './hooks/useCart'
import { useOrders } from './hooks/useOrders'
import type { Address } from './types'
import './index.css'

function App() {
  const [cartOpen, setCartOpen] = useState(false)
  const [search, setSearch] = useState('')
  const [toast, setToast] = useState<string | null>(null)

  const {
    cart,
    addToCart,
    updateQuantity,
    removeFromCart,
    clearCart,
    cartCount,
    cartTotal,
  } = useCart()

  const { orders, addOrder, deleteOrder } = useOrders()

  const handleAddToCart = (product: { _id: string; name: string; price: number }) => {
    addToCart(product as typeof cart[0])
    setToast(`Added ${product.name} to cart`)
  }

  const handlePlaceOrder = (
    name: string,
    phone: string,
    address: Address,
    paymentMethod: string,
    items: typeof cart
  ) => {
    return addOrder(name, phone, address, paymentMethod, items)
  }

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-white/20">
        <Navbar
          cartCount={cartCount}
          search={search}
          setSearch={setSearch}
          onOpenCart={() => setCartOpen(true)}
        />

        <Routes>
          <Route path="/" element={<Home onAddToCart={handleAddToCart} search={search} />} />
          <Route
            path="/checkout"
            element={
              <Checkout
                cart={cart}
                total={cartTotal}
                onPlaceOrder={handlePlaceOrder}
                onClearCart={clearCart}
              />
            }
          />
          <Route path="/admin" element={<Admin orders={orders} onDeleteOrder={deleteOrder} />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>

        <CartDrawer
          isOpen={cartOpen}
          onClose={() => setCartOpen(false)}
          cart={cart}
          total={cartTotal}
          onUpdateQuantity={updateQuantity}
          onRemove={removeFromCart}
        />

        <Toast message={toast} />
      </div>
    </BrowserRouter>
  )
}

export default App
