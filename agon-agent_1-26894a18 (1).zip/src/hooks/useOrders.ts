import { useState, useEffect, useCallback } from 'react'
import type { Order, CartItem, Address } from '../types'

const ORDERS_KEY = 'orders'

export function useOrders() {
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem(ORDERS_KEY)
      return saved ? JSON.parse(saved) : []
    } catch {
      return []
    }
  })

  useEffect(() => {
    localStorage.setItem(ORDERS_KEY, JSON.stringify(orders))
  }, [orders])

  const addOrder = useCallback((
    name: string,
    phone: string,
    address: Address,
    paymentMethod: string,
    items: CartItem[]
  ) => {
    const totalPrice = items.reduce((sum, item) => sum + item.price * item.quantity, 0)
    const order: Order = {
      id: Date.now().toString(),
      name,
      phone,
      address,
      paymentMethod,
      paymentStatus: 'Unpaid',
      status: 'Pending',
      items: items.map((item) => ({
        productId: item._id,
        name: item.name,
        price: item.price,
        quantity: item.quantity,
      })),
      total: totalPrice,
      createdAt: new Date().toISOString(),
    }
    setOrders((prev) => [order, ...prev])
    return order
  }, [])

  const deleteOrder = useCallback((id: string) => {
    setOrders((prev) => prev.filter((order) => order.id !== id))
  }, [])

  return { orders, addOrder, deleteOrder }
}
